<?php
session_start();
session_destroy();
echo "<h2>Cambiar de color</h2>";

echo "<p>Ahora puedes elegir de nuevo un color</p>";
echo "<a href='./index.php'>Volver</a>";


?>
